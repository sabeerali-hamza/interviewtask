app.controller('GridController', ['$scope', '$http', '$routeParams', function($scope, $http, $routeParams){
    scope = $scope;
    $scope.IsVisible = true;
    $http.get("https://api.github.com/users?since=135").then(function (response) {
      $scope.users = response.data;
      var appendUsersData = [];
        angular.forEach($scope.users, function(value,key){
        appendUsersData.push( { login :  value.login, id : value.id, avatar_url : value.avatar_url, action : value.name } );
    });
    $scope.users=appendUsersData;
    $scope.people = $scope.users; 
  });
        scope.sortKey = 'name';
        scope.sortReverse = false;
        scope.itemsPerPage = 5;
        scope.sort = function(key){
            scope.sortReverse = (scope.sortKey == key) ? !scope.sortReverse : scope.sortReverse;
            scope.sortKey = key;
        }
        // view single user below
        $scope.editUser =  function(editUser) {
            //alert(editUser);
            $http.get("https://api.github.com/users/"+editUser).then(function (response) {
              $scope.singleUserData = response.data;
                $scope.IsVisible = false;
          });
        }

}]);